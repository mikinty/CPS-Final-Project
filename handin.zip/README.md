# Probabilistic Model Checking for Algorithmic Trading Strategies via Simulation of Geometric Brownian Motion

![alt text](./logos/logo.jpg)

CPS 15-424 Fall 2018 Final Project.

See `src/` for the code related to this project.